<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '系统公告'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="notice-body"><?php echo _html($data['body']); ?></div>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>