<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $get['id']?'修改管理员':'新增管理员'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">
    <span>管理员管理 &gt;</span>
    <span><?php if($get['id']){ ?>修改<?php }else{ ?>新增<?php } ?>管理员</span>
    <a class="hover J_power" href="<?php echo url('admin/list',$get); ?>">返回</a>
</div>
<form action="<?php echo url('admin/edit'); ?>" method="post" class="J_ajaxform">
    <input type="hidden" value="<?php echo htmlspecialchars($data['id']); ?>" name="id">
    <table class="table">
        <tr>
            <td rowspan="100">
                <input type="hidden" name="avatar" value="<?php echo htmlspecialchars($data['avatar']); ?>" class="J_upload_image" data-error="http://localhost/dev/frame/www/static/admin/images/none.png" data-size="200*200">
            </td>
            <th>选择管理组</th>
            <td>
                <select name="gid" data-selected="<?php echo htmlspecialchars($data['gid']); ?>">
                    <option value="">--请选择管理组--</option>
                    <?php if(!isset($group)||!is_array($group))$group=array();foreach($group as $v){ ?>
                        <option value="<?php echo htmlspecialchars($v['id']); ?>"><?php echo htmlspecialchars($v['name']); ?></option>
                    <?php } ?>
                </select>
                <span class="must">*</span>
                <span class="tip">选择管理组</span>
            </td>
        </tr>
        <tr>
            <th>用户名</th>
            <td>
                <input type="text" name="username" data-disabled="<?php echo htmlspecialchars($data['id']); ?>" value="<?php echo htmlspecialchars($data['username']); ?>">
                <span class="must">*</span>
                <span class="tip">作为登录系统的用户名</span>
            </td>
        </tr>
        <tr>
            <th><?php if($get['id']){ ?>修改密码<?php }else{ ?>设置密码<?php } ?></th>
            <td>
                <input type="text" name="password" value="">
                <?php if(!$get['id']){ ?>
                    <span class="must">*</span>
                    <span class="tip">作为登录系统时的密码</span>
                    <?php }else{ ?>
                    <span class="tip">修改密码后不需要再次登录</span>
                <?php } ?>
            </td>
        </tr>
        <tr>
            <th>昵称</th>
            <td>
                <input type="text" name="nickname" value="<?php echo htmlspecialchars($data['nickname']); ?>">
                <span class="tip">昵称,不填则默认为用户名</span>
            </td>
        </tr>
        <tr>
            <th>手机号</th>
            <td>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($data['phone']); ?>">
                <span class="tip">也可作为登录账号</span>
            </td>
        </tr>
        <tr>
            <th>邮箱</th>
            <td>
                <input type="text" name="mail" value="<?php echo htmlspecialchars($data['mail']); ?>">
                <span class="tip">也可作为登录账号</span>
            </td>
        </tr>
     <!--    <tr>
            <th>是否禁用</th>
            <td>
                <label>
                    <input type="checkbox" name="disable" data-checked="<?php echo htmlspecialchars($data['disable']); ?>" value="2">禁用后将不允许登录
                </label>
                <span class="tip">已登录用户将会退出</span>
            </td>
        </tr> -->
    </table>
    <div class="table-button">
        <a href="<?php echo url('admin/list',$get); ?>" class="btn J_power">返回</a>
        <button class="btn blue">提交</button>
        <a href="javascript:window.location=location.href" class="btn">刷新&amp;重置</a>
    </div>
</form>
<!--图片上传-->
<link href="http://localhost/dev/frame/www/source/cropper/cropper.min.css" rel="stylesheet">
<script src="http://localhost/dev/frame/www/source/cropper/cropper.min.js"></script>
<script src="http://localhost/dev/frame/www/static/admin/js/uploadImage.js"></script>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>