<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $get['id']?'修改公告':'新增公告'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">
    <span>公告管理 &gt;</span>
    <span><?php if($get['id']){ ?>修改<?php }else{ ?>新增<?php } ?>公告</span>
    <a class="hover J_power" href="<?php echo url('notice/list',$get); ?>">返回</a>
</div>
<form action="<?php echo url('notice/edit'); ?>" method="post" class="J_ajaxform">
    <input type="hidden" value="<?php echo htmlspecialchars($data['id']); ?>" name="id">
    <table class="table">
        <tr>
            <th>选择公告类型</th>
            <td>
                <select name="tid" data-selected="<?php echo htmlspecialchars($data['tid']); ?>">
                    <option value="">--请选择公告类型--</option>
                    <?php if(!isset($type)||!is_array($type))$type=array();foreach($type as $v){ ?>
                        <option value="<?php echo htmlspecialchars($v['id']); ?>"><?php echo htmlspecialchars($v['name']); ?></option>
                    <?php } ?>
                </select>
                <span class="must">*</span>
                <span class="tip">选择类型</span>
            </td>
        </tr>
        <tr>
            <th>标题</th>
            <td>
                <input type="text" style="width: 430px" name="title" value="<?php echo htmlspecialchars($data['title']); ?>">
                <span class="must">*</span>
                <span class="tip">必须</span>
            </td>
        </tr>
        <tr>
            <th>内容</th>
            <td>
                <textarea name="body" style="width: 430px; height: 200px"><?php echo htmlspecialchars($data['body']); ?></textarea>
                <span class="must">*</span>
                <span class="tip">简短的文字</span>
            </td>
        </tr>
    </table>
    <div class="table-button">
        <a href="<?php echo url('notice/list',$get); ?>" class="btn J_power">返回</a>
        <button class="btn blue">提交</button>
        <a href="javascript:window.location=location.href" class="btn">刷新&amp;重置</a>
    </div>
</form>

    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>