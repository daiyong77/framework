<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '公告类型设置'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">公告类型设置</div>
<div class="option">
    <a title="添加地区" data-width="500" data-height="200" href="<?php echo url('noticeType/edit',$get); ?>" class="btn blue J_power J_show">添加</a>
    <a title="提交排序" data-url="<?php echo url('noticeType/editSort'); ?>" class="btn blue J_power J_sort_submit">提交排序</a>
</div>
<table class="list">
    <tr>
        <th width="50" class="center">id</th>
        <th width="50" class="center">排序</th>
        <th width="150">地区名称</th>
        <th>操作</th>
    </tr>
    <?php if(!$list){ ?>
        <tr>
            <td colspan="100">未找到任何记录</td>
        </tr>
    <?php } ?>
    <?php if(!isset($list)||!is_array($list))$list=array();foreach($list as $v){ ?>
        <tr>
            <td class="center"><?php echo htmlspecialchars($v['id']); ?></td>
            <td class="center">
                <input type="text" class="sort J_select J_sort" data-id="<?php echo htmlspecialchars($v['id']); ?>" data-default="<?php echo htmlspecialchars($v['sort']); ?>" value="<?php echo htmlspecialchars($v['sort']); ?>">
            </td>
            <td><?php echo htmlspecialchars($v['name']); ?></td>
            <td>
                <a class="J_power J_show" data-refresh="true"  data-width="500" data-height="200"  title="修改<?php echo htmlspecialchars($v['name']); ?>" href="<?php echo url('noticeType/edit',array('id'=>$v['id'])); ?>">
                <i class="fa fa-pencil"></i>
            </a>
                <a title="删除<?php echo htmlspecialchars($v['name']); ?>" href="javascript:;" class="red J_confirm J_power" data-url="<?php echo url('noticeType/delete',array('id'=>$v['id'])); ?>">
                <i class="red fa fa-trash-o"></i>
            </a>
            </td>
        </tr>
    <?php } ?>
</table>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>