<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '主页'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">系统公告</div>
<ul class="home-info">
    <?php if(!$notice){ ?>
        <li>暂无公告</li>
    <?php } ?>
    <?php if(!isset($notice)||!is_array($notice))$notice=array();foreach($notice as $v){ ?>
        <li>
        	<a class="hover J_show" data-read="<?php echo url('my/noticeRead','id='.$v['id']); ?>" href="<?php echo url('my/notice','id='.$v['id']); ?>" data-refresh="false" data-title="<?php echo htmlspecialchars($v['title']); ?>">
                <?php if(!$v['read']){ ?>
                    <font class="J_noread" style="color:red">[未读]</font>
                <?php } ?>
				<font>[<?php echo htmlspecialchars($v['time_create_txt']); ?>]<?php echo htmlspecialchars($v['type']['name']); ?>：<?php echo htmlspecialchars($v['title']); ?></font>
        	</a>
        </li>
    <?php } ?>
</ul>
<script>
    $(function(){
        $('.J_show').click(function(event) {
            if($(this).find('.J_noread').length>0){
                var url=$(this).attr('data-read');
                $(this).find('.J_noread').remove();
                $.get(url, function(data) {
                   console.log(data.message);
                },'json');
            }
        });
    })
</script>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>