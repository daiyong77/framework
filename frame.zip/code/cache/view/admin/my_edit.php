<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '修改我的信息'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">
    <span>修改我的信息</span>
</div>
<form action="<?php echo url('my/edit'); ?>" method="post" class="J_ajaxform" data-callback="callback">
    <table class="table">
        <tr>
            <td rowspan="100">
                <input type="hidden" name="avatar" value="<?php echo htmlspecialchars($data['avatar']); ?>" class="J_upload_image" data-error="http://localhost/dev/frame/www/static/admin/images/none.png" data-size="200*200">
            </td>
            <th>用户名</th>
            <td>
                <input type="text" name="username" data-disabled="<?php echo htmlspecialchars($data['id']); ?>" value="<?php echo htmlspecialchars($data['username']); ?>">
                <span class="must">*</span>
                <span class="tip">作为登录系统的用户名</span>
            </td>
        </tr>
        <tr>
            <th>修改密码</th>
            <td>
                <input type="text" name="password" value="">
                <span class="must"></span>
                <span class="tip">修改密码后不需要再次登录</span>
            </td>
        </tr>
        <tr>
            <th>昵称</th>
            <td>
                <input type="text" name="nickname" value="<?php echo htmlspecialchars($data['nickname']); ?>">
                <span class="tip">昵称,不填则默认为用户名</span>
            </td>
        </tr>
        <tr>
            <th>手机号</th>
            <td>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($data['phone']); ?>">
                <span class="tip">也可作为登录账号</span>
            </td>
        </tr>
        <tr>
            <th>邮箱</th>
            <td>
                <input type="text" name="mail" value="<?php echo htmlspecialchars($data['mail']); ?>">
                <span class="tip">也可作为登录账号</span>
            </td>
        </tr>
    </table>
    <div class="table-button">
        <button class="btn blue">提交</button>
        <a href="javascript:window.location=location.href" class="btn">刷新&amp;重置</a>
    </div>
</form>
<!--图片上传-->
<link href="http://localhost/dev/frame/www/source/cropper/cropper.min.css" rel="stylesheet">
<script src="http://localhost/dev/frame/www/source/cropper/cropper.min.js"></script>
<script src="http://localhost/dev/frame/www/static/admin/js/uploadImage.js"></script>
<script>
//form 回调
function callback(data) {
    if (data.status == 1) {
        var nickname = $('input[name="nickname"]').val();
        if (!nickname) nickname = $('input[name="username"]').val();
        var avatar = $('input[name="avatar"]').val();
        if (!avatar) avatar = 'http://localhost/dev/frame/www/static/admin/images/face.png';
        $('.J_frame_nickname', parent.document).html(nickname);
        $('.J_frame_avatar', parent.document).prop('src', avatar);
    }
    return true;
}
</script>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>