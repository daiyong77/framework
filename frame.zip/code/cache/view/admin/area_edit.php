<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $get['id']?'修改地区':'新增地区'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">
    <span>地区设置 &gt;</span>
    <span><?php if($get['id']){ ?>修改<?php }else{ ?>新增<?php } ?>地区</span>
    <a class="hover J_power" href="<?php echo url('area/list'); ?>">返回</a>
</div>
<form action="<?php echo url('area/edit'); ?>" method="post" class="J_ajaxform">
    <input type="hidden" value="<?php echo htmlspecialchars($data['id']); ?>" name="id">
    <input type="hidden" value="<?php if($data['id']){ ?><?php echo htmlspecialchars($data['fid']); ?><?php }else{ ?><?php echo htmlspecialchars($get['fid']); ?><?php } ?>" name="fid">
    <table class="table">
        <tr>
            <th>地区名称</th>
            <td>
                <input type="text" name="name" value="<?php echo htmlspecialchars($data['name']); ?>">
                <span class="must">*</span>
                <span class="tip">必须</span>
            </td>
        </tr>
    </table>
    <div class="table-button">
        <a href="<?php echo url('area/list',$get); ?>" class="btn J_power">返回</a>
        <button class="btn blue">提交</button>
        <a href="javascript:window.location=location.href" class="btn">刷新&amp;重置</a>
    </div>
</form>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>