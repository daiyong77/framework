<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '公告管理'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">公告管理</div>
<form action="<?php echo url('notice/list'); ?>" method="get">
    <ul class="search">
        <li>
            <dt>公告状态</dt>
            <dd>
                <input type="hidden" name="tid" value="<?php echo htmlspecialchars($get['tid']); ?>">
                <a class="btn-min <?php if(!$get['tid']){ ?>current<?php } ?>" href="<?php echo url('notice/list',$get,'tid=0'); ?>">全部</a>
                <?php if(!isset($type)||!is_array($type))$type=array();foreach($type as $k=>$v){ ?>
                    <a class="btn-min <?php if($get['tid']==$v['id']){ ?>current<?php } ?>" href="<?php echo url('notice/list',$get,'tid='.$v['id']); ?>"><?php echo htmlspecialchars($v['name']); ?></a>
                <?php } ?>
            </dd>
        </li>
        <li>
            <dt></dt>
            <dd>
                <button class="btn green" type="submit">查询</button>
                <a class="btn" href="<?php echo url('notice/list'); ?>">重置</a>
            </dd>
        </li>
    </ul>
</form>
<div class="title line"></div>
<div class="option">
    <a href="<?php echo url('notice/edit',$get); ?>" class="btn blue J_power J_show" data-title="添加公告">添加</a>
</div>
<table class="list">
    <tr>
        <th class="center" width="50">id</th>
        <th width="400">标题</th>
        <th width="170">发布时间</th>
        <th>操作</th>
    </tr>
    <?php if(!$list){ ?>
        <tr>
            <td colspan="100">未找到任何记录</td>
        </tr>
    <?php } ?>
    <?php if(!isset($list)||!is_array($list))$list=array();foreach($list as $v){ ?>
        <tr>
            <td class="center"><?php echo htmlspecialchars($v['id']); ?></td>
            <td>
                <font style="color:green">[<?php echo htmlspecialchars($type[$v['tid']]['name']); ?>]</font><?php echo htmlspecialchars($v['title']); ?>
            </td>
            <td><?php echo htmlspecialchars($v['time_create']); ?></td>
            <td>
                <a title="修改" href="<?php echo url('notice/edit',$get,'id='.$v['id']); ?>" class="J_power J_show" data-title="修改公告">
                        <i class="fa fa-pencil"></i>
                    </a>
                <a title="删除<?php echo htmlspecialchars($v['title']); ?>" href="javascript:;" class="red J_confirm J_power" data-url="<?php echo url('notice/delete',array('id'=>$v['id'])); ?>">
                        <i class="red fa fa-trash-o"></i>
                    </a>
            </td>
        </tr>
    <?php } ?>
</table>
<?php 
    if(isset($page)&&$page){
    if(isset($get)&&$get){
    unset($get['page']);
    }
    $url1=$config['sys']['controller'].'/'.$config['sys']['action'];
    }else{
    $page['all']=0;
    }
 ?>
<?php if($page['all']>1){ ?>
    <div class="option page-fixed">
        <ul class="page">
            <li>
                <a href="<?php echo url($url1,$get,'page=1'); ?>" title="第一页">
                <i class="fa fa-angle-double-left"></i>
            </a>
            </li>
            <li>
                <a href="<?php echo url($url1,$get,'page='.$page['prev']); ?>" title="上一页">
                <i class="fa fa-angle-left"></i>
            </a>
            </li>
            <?php if($page['now']>4){ ?>
                <li><a href="<?php echo url($url1,$get,'page=1'); ?>">1...</a></li>
                <?php }elseif($page['now']!=1){ ?>
                <li><a href="<?php echo url($url1,$get,'page=1'); ?>">1</a></li>
            <?php } ?>
            <?php for($i=$page['now']-5;$i<$page['now'];$i++){ ?>
                <?php if(1 >=$i )continue; ?>
                <li>
                    <a href="<?php echo url($url1,$get,'page='.$i); ?>"><?php echo htmlspecialchars($i); ?></a>
                </li>
            <?php } ?>
            <li class="current"><a href="javascript:;"><?php echo htmlspecialchars($page['now']); ?></a></li>
            <?php for($i=$page['now']+1;$i<$page['now']+6;$i++){ ?>
                <?php if($i >= $page['all'])continue; ?>
                <li>
                    <a href="<?php echo url($url1,$get,'page='.$i); ?>"><?php echo htmlspecialchars($i); ?></a>
                </li>
            <?php } ?>
            <?php if($page['now']+3<$page['all']){ ?>
                <li><a href="<?php echo url($url1,$get,'page='.$page['all']); ?>">...<?php echo htmlspecialchars($page['all']); ?></a></li>
                <?php }elseif($page['now']!=$page['all']){ ?>
                <li><a href="<?php echo url($url1,$get,'page='.$page['all']); ?>"><?php echo htmlspecialchars($page['all']); ?></a></li>
            <?php } ?>
            <li>
                <a title="下一页" href="<?php echo url($url1,$get,'page='.$page['next']); ?>">
                <i class="fa fa-angle-right"></i>
            </a>
            </li>
            <li>
                <a title="最后一页" href="<?php echo url($url1,$get,'page='.$page['all']); ?>">
                <i class="fa fa-angle-double-right"></i>
            </a>
            </li>
            <li class="all">
                <a href="javascript:;">共<?php echo htmlspecialchars($page['count']); ?>条(每页<?php echo htmlspecialchars($config['custom']['page_list']); ?>条)</a>
            </li>
        </ul>
    </div>
<?php } ?>
    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>