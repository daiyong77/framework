<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo '管理员管理'; ?></title>
    <!-- 双核浏览器默认使用急速模式 -->
    <meta name="renderer" content="webkit">
    <link rel="stylesheet" href="http://localhost/dev/frame/www/static/admin/css/style.css">
    <script src="http://localhost/dev/frame/www/source/jquery1.js"></script>
    <script src="http://localhost/dev/frame/www/source/layer/layer.js"></script>
    <script src="http://localhost/dev/frame/www/static/admin/js/script.js"></script>
    <script>
var _G = {
	imageUploadPath:"<?php echo url('image/index',array(),'uploads'); ?>",
	imageUploadMaxSize:2,//最大上传限制M
    power: "<?php echo implode(',',$admin['group']['power']?$admin['group']['power']:array()); ?>".split(',')
}
</script>
</head>

<body>
    
<div class="title">管理员管理</div>
<form action="<?php echo url('admin/list'); ?>" method="get">
    <ul class="search">
        <li>
            <dt>按用户名搜索</dt>
            <dd>
                <input type="text" name="username" value="<?php echo htmlspecialchars($get['username']); ?>">
            </dd>
        </li>
        <li>
            <dt>按手机号搜索</dt>
            <dd>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($get['phone']); ?>">
            </dd>
        </li>
        <!--     <li>
            <dt>按邮箱搜索</dt>
            <dd>
                <input type="text" name="mail" value="<?php echo htmlspecialchars($get['mail']); ?>">
            </dd>
        </li>  -->
        <li>
            <dt>选择管理组</dt>
            <dd>
                <select onchange="this.form.submit()" name="gid" data-selected="<?php echo htmlspecialchars($get['gid']); ?>">
                    <option value="">--选择管理组--</option>
                    <?php if(!isset($group)||!is_array($group))$group=array();foreach($group as $v){ ?>
                        <option value="<?php echo htmlspecialchars($v['id']); ?>"><?php echo htmlspecialchars($v['name']); ?></option>
                    <?php } ?>
                </select>
            </dd>
        </li>
        <li>
            <dt>选择状态</dt>
            <dd>
                <input type="hidden" name="disable" value="<?php echo htmlspecialchars($get['disable']); ?>">
                <a class="btn-min <?php if(!$get['disable']){ ?>current<?php } ?>" href="<?php echo url('admin/list',$get,'disable=0'); ?>">全部</a>
                <?php if(!isset($disable)||!is_array($disable))$disable=array();foreach($disable as $k=>$v){ ?>
                     <a class="btn-min <?php if($get['disable']==$k){ ?>current<?php } ?>" href="<?php echo url('admin/list',$get,'disable='.$k); ?>"><?php echo htmlspecialchars($v); ?></a>
                <?php } ?>
            </dd>
        </li>
        <li>
            <dt></dt>
            <dd>
                <button class="btn green" type="submit">查询</button>
                <a class="btn" href="<?php echo url('admin/list'); ?>">重置</a>
            </dd>
        </li>
    </ul>
</form>
<div class="title line"></div>
<div class="option">
    <a href="<?php echo url('admin/edit',$get); ?>" class="btn blue J_power">添加</a>
    <a href="<?php echo url('admin/listExport',$get); ?>" class="btn orange J_power">按查询结果导出(共<?php echo htmlspecialchars($page['count']); ?>条)</a>
</div>
<table class="list">
    <tr>
        <th class="center" width="50">id</th>
        <th width="150">用户名</th>
        <!-- <th width="120">昵称(姓名)</th> -->
        <th width="120">管理组</th>
        <th width="120">电话</th>
        <!-- <th width="240">邮箱</th> -->
        <th width="80" class="center">当前状态</th>
        <th>操作</th>
    </tr>
    <?php if(!$list){ ?>
        <tr>
            <td colspan="100">未找到任何记录</td>
        </tr>
    <?php } ?>
    <?php if(!isset($list)||!is_array($list))$list=array();foreach($list as $v){ ?>
        <tr>
            <td class="center"><?php echo htmlspecialchars($v['id']); ?></td>
            <td><?php echo htmlspecialchars($v['username']); ?></td>
            <!-- <td><?php echo htmlspecialchars($v['nickname']); ?></td> -->
            <td><?php echo htmlspecialchars($group[$v['gid']]['name']); ?></td>
            <td><?php echo htmlspecialchars($v['phone']); ?></td>
            <!-- <td><?php echo htmlspecialchars($v['mail']); ?></td> -->
            <td class="center">
                <?php if($v['disable']==1){ ?>
                    <font class="green">
                        <a href="javascript:;" class="J_ajaxa hover green J_power_html" data-url="<?php echo url('admin/editDisable',array('id'=>$v['id'],'disable'=>2)); ?>"><?php echo htmlspecialchars($disable[$v['disable']]); ?></a>
                    </font>
                    <?php }elseif($v['disable']==2){ ?>
                    <font class="red">
                        <a href="javascript:;" class="J_ajaxa hover red J_power_html" data-url="<?php echo url('admin/editDisable',array('id'=>$v['id'],'disable'=>1)); ?>"><?php echo htmlspecialchars($disable[$v['disable']]); ?></a>
                    </font>
                <?php } ?>
            </td>
            <td>
                <a title="修改" href="<?php echo url('admin/edit',$get,'id='.$v['id']); ?>" class="J_power">
                        <i class="fa fa-pencil"></i>
                    </a>
                <a title="删除<?php echo htmlspecialchars($v['username']); ?>" href="javascript:;" class="red J_confirm J_power" data-url="<?php echo url('admin/delete',array('id'=>$v['id'])); ?>">
                        <i class="red fa fa-trash-o"></i>
                    </a>
            </td>
        </tr>
    <?php } ?>
</table>
<?php 
    if(isset($page)&&$page){
    if(isset($get)&&$get){
    unset($get['page']);
    }
    $url1=$config['sys']['controller'].'/'.$config['sys']['action'];
    }else{
    $page['all']=0;
    }
 ?>
<?php if($page['all']>1){ ?>
    <div class="option page-fixed">
        <ul class="page">
            <li>
                <a href="<?php echo url($url1,$get,'page=1'); ?>" title="第一页">
                <i class="fa fa-angle-double-left"></i>
            </a>
            </li>
            <li>
                <a href="<?php echo url($url1,$get,'page='.$page['prev']); ?>" title="上一页">
                <i class="fa fa-angle-left"></i>
            </a>
            </li>
            <?php if($page['now']>4){ ?>
                <li><a href="<?php echo url($url1,$get,'page=1'); ?>">1...</a></li>
                <?php }elseif($page['now']!=1){ ?>
                <li><a href="<?php echo url($url1,$get,'page=1'); ?>">1</a></li>
            <?php } ?>
            <?php for($i=$page['now']-5;$i<$page['now'];$i++){ ?>
                <?php if(1 >=$i )continue; ?>
                <li>
                    <a href="<?php echo url($url1,$get,'page='.$i); ?>"><?php echo htmlspecialchars($i); ?></a>
                </li>
            <?php } ?>
            <li class="current"><a href="javascript:;"><?php echo htmlspecialchars($page['now']); ?></a></li>
            <?php for($i=$page['now']+1;$i<$page['now']+6;$i++){ ?>
                <?php if($i >= $page['all'])continue; ?>
                <li>
                    <a href="<?php echo url($url1,$get,'page='.$i); ?>"><?php echo htmlspecialchars($i); ?></a>
                </li>
            <?php } ?>
            <?php if($page['now']+3<$page['all']){ ?>
                <li><a href="<?php echo url($url1,$get,'page='.$page['all']); ?>">...<?php echo htmlspecialchars($page['all']); ?></a></li>
                <?php }elseif($page['now']!=$page['all']){ ?>
                <li><a href="<?php echo url($url1,$get,'page='.$page['all']); ?>"><?php echo htmlspecialchars($page['all']); ?></a></li>
            <?php } ?>
            <li>
                <a title="下一页" href="<?php echo url($url1,$get,'page='.$page['next']); ?>">
                <i class="fa fa-angle-right"></i>
            </a>
            </li>
            <li>
                <a title="最后一页" href="<?php echo url($url1,$get,'page='.$page['all']); ?>">
                <i class="fa fa-angle-double-right"></i>
            </a>
            </li>
            <li class="all">
                <a href="javascript:;">共<?php echo htmlspecialchars($page['count']); ?>条(每页<?php echo htmlspecialchars($config['custom']['page_list']); ?>条)</a>
            </li>
        </ul>
    </div>
<?php } ?>

    <?php if($_SERVER['REMOTE_ADDR']=='127.0.0.1'){ ?>
        <div style="position: fixed;z-index: 999;background: red;right: 0px;bottom: 0px;">
            <a class="hover" target="_blank" style="color: #000" href="<?php echo url($config['sys']['controller'].'/'.$config['sys']['action'],@$get); ?>">
                <?php echo htmlspecialchars($config['sys']['controller']); ?>/<?php echo htmlspecialchars($config['sys']['action']); ?>
            </a>
        </div>
    <?php } ?>
    <link rel="stylesheet" href="http://localhost/dev/frame/www/source/font-awesome/font-awesome.css">
</body>

</html>